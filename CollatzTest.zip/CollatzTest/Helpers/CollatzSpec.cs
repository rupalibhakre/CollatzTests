﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollatzTest.Helpers
{
    class CollatzSpec
    {

        public int Collatz(int num)
        {

            int answer = -1;
            int maxTry = 500;
            int count = 0;

            if (num == 1)
                return count;
            for (count = 0; count < maxTry; count++)
            {
                // 1-1
                if (num % 2 == 0)
                {
                    num /= 2;
                }
                // 1-2
                else if (num % 2 == 1)
                {
                    num = num * 3 + 1;
                }

                if (num == 1)
                {
                    answer = count + 1;
                    break;
                }
            }

            Console.Write(answer);
            return answer;
        }
    }
    }
