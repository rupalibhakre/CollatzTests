﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using RestSharp;
using BoDi;
using NUnit.Framework;
using System.Net;
using CollatzTest.Helpers;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;

namespace CollatzTest.Steps
{
    [Binding, Scope(Feature = "Collatz")]
    public sealed class CollatzSteps
    {
        public static IRestClient Client;
        
        public static IRestRequest Request;

        public static IRestResponse Response;

        public static IObjectContainer _objectContainer;

        private int _id;

        private int _num;

        private int _amount;

        public CollatzSteps(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [Given(@"Platform API (.*) is available")]
        public void GivenPlatformAPIIsAvailable(string baseUrl)
        {
            Client = new RestClient("http://127.0.0.1:8080");
        }

        [When(@"I create the machine")]
        public void WhenICreateTheMachine()
        {
            
            Random a = new Random();
            _id = a.Next(1, 500);

            Random b = new Random();
            _num = b.Next(1, 500);

            Request = new RestRequest("create/"+_id+"/"+_num, Method.POST);
        }

        [When(@"I destroy the machine")]
        public void WhenIDestroyTheMachine()
        {
            Request = new RestRequest("destroy/"+_id, Method.POST);
        }

        [When(@"I get the messages for an id")]
        public void WhenIGetTheMessagesForAnId()
        {
            Request = new RestRequest("messages/"+_id, Method.GET);
        }

        [When(@"I get all messages")]
        public void WhenIGetAllMessages()
        {
            Request = new RestRequest("messages", Method.GET);
        }

        [When(@"I increment the machine by amount")]
        public void WhenIIncrementTheMachineByAmount()
        {
            Random a = new Random();
            _id = a.Next(1, 500);

            Random c = new Random();
            _amount = c.Next(1, 100);

            Request = new RestRequest("increment/"+_id +"/"+_amount, Method.POST);
        }



        [Then(@"I get response status code (.*)")]
        public void ThenIGetResponseStatusCode(int statusCode)
        {
           
            Response = Client.Execute(Request);
            Assert.AreEqual(statusCode, ((int)Response.StatusCode));
            
        }

        [Then(@"I get a continuous stream")]
        public async Task ThenIGetAContinuousStreamAsync()
        {
            var HttpClient = new HttpClient();
            var stream = await HttpClient.GetStreamAsync("http://127.0.0.1:8080/messages/" + _id);
            var reader = new StreamReader(stream);
            while (true)
            {
                Console.WriteLine(reader.ReadLine());
            }
        }



    }
}
